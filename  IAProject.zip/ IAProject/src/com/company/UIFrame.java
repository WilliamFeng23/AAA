package com.company;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.io.FileWriter;
import java.io.IOException;

public class UIFrame extends JFrame implements ActionListener {
    public JComboBox comboBox;
    public JTextField[] input = new JTextField[5];
    public JButton getLogin;
    public JButton makeAccount;
    public JButton redButton;
    public JButton blueButton;
    public JLabel result;
    public JLabel[] labels = new JLabel[5];
    public File myfile;
    public FileWriter editor;
    // Variables for login
    private String password = "1234";
    private String username = "user";
    //Variables for File manipulation
    public String[] data = new String[1000];
    public String[] data2 = new String[1000];
    public String[] loginCredentials = new String[3];
    public String fileName1 = "C:\\Users\\fengwil23\\IdeaProjects\\IAProject\\src\\com\\company\\mainStorage.txt";
    public String fileName2 = "C:\\Users\\william\\IdeaProjects\\shape3D\\src\\com\\company\\mainStorage.txt";
    public JButton done;
    public String[] message = new String[100];


    // Gridlayout uses one column which is the most convenient
    UIFrame() {
        // File Stuff
        int x = 0;
        try
        {
            // File Location of PC at home
            // C:\Users\william\IdeaProjects\shape3D\src\com\company\mainStorage.txt
            // File location of School PC
            // C:\Users\fengwil23\IdeaProjects\ IAProject\src\com\company\mainStorage.txt
            this.myfile = new File("UserStorage.txt");
//            myfile.setWritable(true);
//            myfile.setReadable(true);
            //this.editor = new FileWriter(myfile);
            Scanner sc = new Scanner(myfile);
            while(sc.hasNextLine())
            {
                this.data[x] = sc.nextLine();
                System.out.println(data[x]);
                x++;
            }
            System.out.println(Arrays.toString(data));
            sc.close();
            if(this.myfile.exists())
            {
                System.out.println("File name: " + this.myfile.getName());
                System.out.println("Absolute path: " + this.myfile.getAbsolutePath());
                System.out.println("Writeable: " + this.myfile.canWrite());
                System.out.println("Readable " + this.myfile.canRead());
                System.out.println("File size in bytes " + this.myfile.length());
            }
            else
            {
                System.out.println("DNE");
            }
        } catch(FileNotFoundException e)
        {
            System.out.println("An error occured.");
            e.printStackTrace();
        } catch(Exception e)
        {
            System.out.println(e);
        }

        // Jpanel
        JPanel panel = new JPanel();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(new GridLayout(20, 1));
        this.add(panel);
        String[] shapes = {"Login", "Settings"};
        comboBox = new JComboBox(shapes);

        // Action Listener that triggers when the comboSelection changes (listens for events)
        comboBox.addActionListener(this);
        panel.add(comboBox);
        for (int i = 0; i < 5; i++) {
            labels[i] = new JLabel();
            input[i] = new JTextField();
            input[i].setPreferredSize(new Dimension(250, 40));
            panel.add(labels[i]);
            panel.add(input[i]);
            input[i].setVisible(false);
        }

        // Setting text for login page
        input[0].setVisible(true);
        input[1].setVisible(true);
        labels[0].setText("Username");
        labels[1].setText("Password");

        // Login Button
        getLogin = new JButton("Login");
        getLogin.setBackground(Color.blue);
        getLogin.addActionListener(this);
        getLogin.setForeground(Color.white);
        panel.add(getLogin);

        // Sign up Button
        makeAccount = new JButton("Sign Up");
        makeAccount.setBackground(Color.black);
        makeAccount.addActionListener(this);
        makeAccount.setForeground(Color.white);
        panel.add(makeAccount);

        // UI Red Background  Button
        redButton = new JButton("Red");
        redButton.setBackground(Color.RED);
        redButton.addActionListener(this);
        redButton.setForeground(Color.white);
        panel.add(redButton);
        redButton.setVisible(false);

        // UI Blue Background Button
        blueButton = new JButton("Blue");
        blueButton.setBackground(Color.BLUE);
        blueButton.addActionListener(this);
        blueButton.setForeground(Color.white);
        panel.add(blueButton);
        blueButton.setVisible(false);

        done = new JButton("Done");
        done.setBackground(Color.black);
        done.addActionListener(this);
        done.setForeground(Color.white);
        panel.add(done);
        done.setVisible(false);

        result = new JLabel("Result");
        panel.add(result);
        this.pack();
        this.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int index = comboBox.getSelectedIndex();
        if (e.getSource() == comboBox) {
            result.setText("");
            if (index == 0) {
                for (int i = 0; i < 5; i++) {
                    input[i].setVisible(false);
                    labels[i].setVisible(false);
                }

                for (int i = 0; i < 2; i++) {
                    input[i].setVisible(true);
                    labels[i].setVisible(true);
                }

                redButton.setVisible(false);
                blueButton.setVisible(false);
                input[0].setVisible(true);
                input[1].setVisible(true);
                labels[0].setText("Username");
                labels[1].setText("Password");

                getLogin.setVisible(true);
                result.setVisible(true);
                this.pack();
                this.setVisible(true);

            } else if (index == 1) {
                for (int i = 1; i < 5; i++) {
                    input[i].setVisible(false);
                    labels[i].setVisible(false);
                }
                redButton.setVisible(true);
                blueButton.setVisible(true);

            } else if (index == 2) {
                for (int i = 1; i < 5; i++) {
                    input[i].setVisible(false);
                    labels[i].setVisible(false);
                }
                labels[0].setVisible(true);
                labels[0].setText("Please input radius");
                input[0].setVisible(true);

            } else if (index == 3) {
                for (int i = 0; i < 5; i++) {
                    input[i].setVisible(true);
                    labels[i].setVisible(true);
                }
                labels[0].setText("Please input base");
                labels[1].setText("Please input height");
                labels[2].setText("Please input length");
                labels[3].setText("Please input s1");
                labels[4].setText("Please input s2");
            } else if (index == 4) {
                for (int i = 1; i < 5; i++) {
                    input[i].setVisible(false);
                    labels[i].setVisible(false);
                }
                input[0].setVisible(true);
                input[1].setVisible(true);
                labels[0].setVisible(true);
                labels[1].setVisible(true);
                labels[0].setText("Please input radius");
                labels[1].setText("Please input height");
            } else if (index == 5) {
                for (int i = 1; i < 5; i++) {
                    input[i].setVisible(false);
                    labels[i].setVisible(false);
                }
                input[0].setVisible(true);
                input[1].setVisible(true);
                labels[0].setVisible(true);
                labels[1].setVisible(true);
                labels[0].setText("Please input radius");
                labels[1].setText("Please input height");
            }
        } else if (e.getSource() == getLogin) {
            if (index == 0) {
                String storedUsername = this.username;
                String storedPassword = this.password;
                System.out.println(storedUsername);
                System.out.println(storedPassword);
                String inputtedUsername = input[0].getText();
                String inputtedPassword = input[1].getText();
                for(int i = 0; i < 2; i++)
                {
                    input[i].setText("");
                }
                System.out.println(inputtedUsername);
                System.out.println(inputtedPassword);
                if(inputtedUsername.equals(storedUsername) && inputtedPassword.equals(storedPassword))
                {
                    System.out.println("Success");
                    result.setText("Logging in..");
                    loadMainUI();
                }
                else
                {
                    result.setText("Your login failed.");
                }
            }
            if (index == 1) {

            }
            if (index == 2) {

            }
            if (index == 3) {

            }
            if (index == 4) {

            }
            if (index == 5) {

            }
            if (index == 0) {

            }
            if (index == 1) {

            }
            if (index == 2) {

            }
            if (index == 3) {

            }
            if (index == 4) {

            }
            if (index == 5) {

            }
        }
        else if(e.getSource() == makeAccount)
        {
            done.setVisible(true);
            getLogin.setVisible(false);
            makeAccount.setVisible(false);

            for(int i = 0; i < 2; i++)
            {
                input[i].setText("");
            }
            input[0].setVisible(true);
            input[1].setVisible(true);
            input[2].setVisible(true);
            labels[0].setText("Input an email");
            labels[1].setText("Input a username");
            labels[2].setText("Input a password");

            //writeToFile();
        }
        else if(e.getSource() == done)
        {
//            for(int i = 0; i < 3; i++)
//            {
//                message[i] = input[i].getText();
//            }
            try
            {
                this.editor = new FileWriter("userStorage.txt");
                message[0] = input[0].getText();
                message[1] = input[1].getText();
                message[2] = input[2].getText();
                writeToFile(message, this.editor);
            } catch (IOException ioException)
            {
                ioException.printStackTrace();
            }
        }
    }
    public void loadMainUI()
    {
        result.setText("");
        for (int i = 3; i < 5; i++) {
            input[i].setVisible(false);
            labels[i].setVisible(false);
        }

        for (int i = 0; i < 3; i++) {
            input[i].setVisible(true);
            labels[i].setVisible(true);
        }
        labels[0].setText("Date");
        labels[1].setText("Expense Cost");
        labels[2].setText("Extra Description");
        getLogin.setVisible(false);
    }

    public void writeToFile(String[] message, FileWriter ek)
    {
        try
        {
            this.fileName1 = fileName1;
            for(int i = 0; i < message.length; i++)
            {
                ek.write(message[i]);
            }
            System.out.println(Arrays.toString(message));
            ek.close();
        } catch(IOException e)
        {
            System.out.println("An error occured");
        }
    }

}



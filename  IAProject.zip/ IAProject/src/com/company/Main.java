package com.company;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


public class Main {

    public static void main(String[] args) {
        //UIFrame UI = new UIFrame();
        String[] message = {"Bruce", "is", "a", "skyblock", "addict"};
        FileWriter x;
        writeToFile(message);
    }

    public static void writeToFile(String[] message)
    {
        try
        {
            FileWriter fileWriter = new FileWriter("userStorage.txt");
            for(int i = 0; i < message.length; i++)
            {
                fileWriter.write(message[i]);
                fileWriter.write("\n");
                System.out.println("success");
            }
            System.out.println(Arrays.toString(message));
            fileWriter.close();
        } catch(IOException e)
        {
            System.out.println("An error occured");
        }
    }
}

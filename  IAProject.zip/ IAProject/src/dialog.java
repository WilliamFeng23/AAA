import javax.swing.*;
import java.awt.event.*;

public class dialog
{
    private JTextField textField1;
    private JButton exitButton;
    private JTextField textField2;
    private JPanel SignUp;
    private JButton doneButton;

    public dialog()
    {

    }
    public static void signUpPage()
    {
        //setLogin()
    }
}

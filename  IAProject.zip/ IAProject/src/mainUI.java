import javax.swing.*;
import java.awt.event.*;

public class mainUI extends JDialog
{
    private JPanel contentPane;
    private JPanel signUp;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField textField1;
    private JTextField textField2;
    private JButton buttonSignUp;
    public String username = "username";
    public String password = "password";

    public mainUI()
    {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onOK();
            }
        });

        buttonCancel.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onCancel();
            }
        });

        buttonSignUp.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onSignUp();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(e -> onCancel(), KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onOK()
    {
        // add your code here
        String username = textField1.getText();
        String password = textField2.getText();
        System.out.println("Username: " + username + "\n" + "Password: " + password);
        if(this.username.equals(username) && this.password.equals(password))
        {
            System.out.println("Initial Login Success (mainUI.java");

        }
        else
        {
            System.out.println("Initial Login Failed (mainUI.java)");
            textField1.setText("");
            textField2.setText("");
        }
    }

    private void onCancel()
    {
        // add your code here if necessary
        System.out.println("mainUI.java Interface cancled");
        dispose();
    }

    private void onSignUp()
    {
        String[] void2 = new String[50];
        dispose();
        SignUp.main(void2);

    }

    public static void main(String[] args)
    {
        mainUI dialog = new mainUI();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}

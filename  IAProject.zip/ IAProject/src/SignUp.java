import javax.swing.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SignUp extends JDialog
{
    private JPanel contentPane;
    private JButton buttonDone;
    private JButton buttonExit;
    private JTextField textField1;
    private JTextField textField2;
    private JButton backToLoginButton;
    public String username;
    public String password;
    public String[] tempHolder = new String[2];

    public SignUp()
    {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonDone);

        buttonDone.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onOK();
            }
        });

        buttonExit.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onOK()
    {
        this.tempHolder[0] = textField1.getText();
        this.tempHolder[1] = textField2.getText();
        for(int i = 0; i < 2; i++)
        {
            if(tempHolder[i] == "")
            {
                textField1.setText("");
                textField2.setText("");
                break;
            }
        }
        // add your code here
//        try
//        {
//            File userFile = new File("loginCredentials.txt");
//            Scanner sc = new Scanner(userFile);
//            while(sc.hasNextLine())
//            {
//
//            }
//        } catch(FileNotFoundException e)
//        {
//            System.out.println("Error");
//        }
        try
        {
            FileWriter fileWriter = new FileWriter("loginCredentials.txt");
            for(int i = 0; i < 2; i++)
            {
                fileWriter.write(tempHolder[i]);
                fileWriter.write("\n");
            }
            System.out.println("Success");
            fileWriter.close();
        } catch(IOException e)
        {
            System.out.println(e);
        }
        dispose();
    }

    private void onCancel()
    {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args)
    {
        SignUp dialog = new SignUp();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
